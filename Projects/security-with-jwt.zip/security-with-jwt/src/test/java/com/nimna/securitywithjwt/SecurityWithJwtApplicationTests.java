package com.nimna.securitywithjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityWithJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
