package com.nimna.securitywithjwt.service;

import com.nimna.securitywithjwt.entity.Role;

public interface RoleService {
    String createRole(Role role);
}
