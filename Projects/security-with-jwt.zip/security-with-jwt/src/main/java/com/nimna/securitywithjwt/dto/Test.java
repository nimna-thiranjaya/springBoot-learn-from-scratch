package com.nimna.securitywithjwt.dto;

public class Test {
}
